#include <iostream>
#include <string>
#include <vector>

 using namespace std;
struct LabResult {
    string testName;
    double result;
};

struct ClinicalData {
    string diagnosis;
    vector<LabResult> labResults;
};

struct Patient {
    string firstName;
    string lastName;
    int age;
    ClinicalData clinicalData;
};

vector<Patient> patients; // Store patient records

void addPatient() {
    Patient patient;
    cout << "Enter first name: "<< endl;
    cin >> patient.firstName;
    cout << "Enter last name: "<< endl;
    cin >> patient.lastName;
    cout << "Enter age: "<< endl;
    cin >> patient.age;

    cout << "Enter diagnosis: "<< endl;
    cin.ignore(); // Clear newline character from previous input
    getline(cin, patient.clinicalData.diagnosis);

    int numLabResults;
    cout << "Enter the number of lab results: "<< endl;
    cin >> numLabResults;

    for (int i = 0; i < numLabResults; ++i) {
        LabResult labResult;
        cout << "Enter lab test name: "<< endl;
        cin.ignore(); // Clear newline character from previous input
        getline(cin, labResult.testName);
        cout << "Enter lab test result: "<< endl;
        cin >> labResult.result;
        patient.clinicalData.labResults.push_back(labResult);
    }

    patients.push_back(patient);
    cout << "Patient information added successfully!\n"<< endl;
}

void displayPatients() {
    if (patients.empty()) {
        cout << "No patients found.\n"<< endl;
        return;
    }

    cout << "Patient Records:\n"<< endl;
    for (const Patient &patient : patients) {
        cout << "Name: " << patient.firstName << " " << patient.lastName << "\n"<< endl;
        cout << "Age: " << patient.age << "\n"<< endl;
        cout << "Diagnosis: " << patient.clinicalData.diagnosis << "\n"<< endl;

        if (!patient.clinicalData.labResults.empty()) {
            cout << "Lab Results:\n"<< endl;
            for (const LabResult &labResult : patient.clinicalData.labResults) {
                cout << labResult.testName << ": " << labResult.result << "\n"<< endl;
            }
        }

        cout << "\n"<< endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "Medical Information System\n"<< endl;
        cout << "1. Add Patient\n"<< endl;
        cout << "2. Display Patients\n"<< endl;
        cout << "3. Exit\n"<< endl;
        cout << "Enter your choice: "<< endl;
        cin >> choice;

        if (choice == 1) {
            addPatient();
        } else if (choice == 2) {
            displayPatients();
        } else if (choice == 3) {
            cout << "Exiting program.\n"<< endl;
            break;
        } else {
            cout << "Invalid choice. Please try again.\n"<< endl;
        }
    }

    return 0;
}

